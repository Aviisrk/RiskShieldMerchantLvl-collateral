-- QUERY 3 · CHUNK B (EMAIL) : cross-merchant dispute-ratio via disputed EMAILS  [Risk Desk · Redshift · self-contained, MID __MID__]
-- Companion of q3a_cross_phone.sql. One clean email semi-join, own timeout budget.
-- Shares the 9-col schema with chunk A; paste both grids into the Q3 box.
WITH tx AS (
    SELECT t.transactionid, CAST(t.cforderid AS VARCHAR) AS cforderid
    FROM cfsellers.cftransactions t
    WHERE t.merchantid = __MID__ AND t.txtime >= date_add('day', -__DAYS__, current_date)
),
disp_on_txn_src AS (SELECT CAST(md.cftxnid AS VARCHAR) AS cftxnid
    FROM cfsellers.merchantdisputes md
    WHERE md.merchantid = __MID__ AND md.addedon >= date_add('day', -__DAYS__, current_date) GROUP BY 1),
dispe AS (SELECT t.transactionid, t.cforderid FROM tx t JOIN disp_on_txn_src d ON t.transactionid = d.cftxnid),
ord AS (
    SELECT DISTINCT NULLIF(TRIM(o.customeremail), '') AS email
    FROM dispe d JOIN cfsellers.cforders o ON d.cforderid = CAST(o.id AS VARCHAR)
    WHERE o.merchantid = __MID__ AND o.addedon >= date_add('day', -__SLACK__, current_date)),
filter_emails AS (SELECT email FROM ord WHERE email IS NOT NULL),
-- network-wide orders whose email matches a disputed email (excl. source merchant)
matched_orders AS (
    SELECT CAST(o.id AS VARCHAR) AS orderid, CAST(o.merchantid AS VARCHAR) AS ord_merchantid,
           NULLIF(TRIM(o.customeremail), '') AS email
    FROM cfsellers.cforders o
    WHERE o.addedon >= date_add('day', -__DAYS__, current_date)
      AND o.merchantid <> __MID__
      AND NULLIF(TRIM(o.customeremail), '') IN (SELECT email FROM filter_emails)
),
mo_merchants AS (SELECT DISTINCT CAST(ord_merchantid AS INTEGER) AS mid FROM matched_orders),
txn_core AS (
    SELECT t.transactionid, CAST(t.merchantid AS VARCHAR) AS merchantid,
           CAST(t.cforderid AS VARCHAR) AS cforderid, t.capturedamount, t.txstatus
    FROM cfsellers.cftransactions t
    WHERE t.txtime >= date_add('day', -__DAYS__, current_date)
      AND t.merchantid IN (SELECT mid FROM mo_merchants)
),
disp_on_txn AS (
    SELECT CAST(md.cftxnid AS VARCHAR) AS cftxnid, MAX(md.disputeamount) AS damt, 1 AS dcnt
    FROM cfsellers.merchantdisputes md
    WHERE md.addedon >= date_add('day', -__DAYS__, current_date) GROUP BY 1),
matches AS (
    SELECT 'EMAIL' AS idtype, mo.email AS idvalue, tc.transactionid, tc.merchantid, tc.capturedamount, tc.txstatus
    FROM txn_core tc JOIN matched_orders mo
      ON tc.cforderid = mo.orderid AND tc.merchantid = mo.ord_merchantid
    WHERE mo.email IS NOT NULL
),
scored AS (
    SELECT m.idtype, m.idvalue, m.merchantid, m.transactionid,
           CASE WHEN m.txstatus = 'SUCCESS' THEN m.capturedamount ELSE 0 END AS cap,
           COALESCE(d.damt,0) AS damt, COALESCE(d.dcnt,0) AS dcnt
    FROM (SELECT DISTINCT idtype, idvalue, merchantid, transactionid, capturedamount, txstatus FROM matches) m
    LEFT JOIN disp_on_txn d ON m.transactionid = d.cftxnid
)
SELECT 'PER_MERCHANT' AS scope, idtype, idvalue, merchantid,
       SUM(cap) AS captured_amt, SUM(damt) AS disputed_amt,
       COUNT(DISTINCT transactionid) AS tx_count, SUM(dcnt) AS dispute_count,
       100.0*SUM(damt)/NULLIF(SUM(cap),0) AS dispute_ratio_pct
FROM scored GROUP BY idtype, idvalue, merchantid
UNION ALL
SELECT 'OVERALL', idtype, idvalue, 'ALL', SUM(cap), SUM(damt),
       COUNT(DISTINCT transactionid), SUM(dcnt), 100.0*SUM(damt)/NULLIF(SUM(cap),0)
FROM scored GROUP BY idtype, idvalue
ORDER BY scope, disputed_amt DESC NULLS LAST, dispute_ratio_pct DESC NULLS LAST;
