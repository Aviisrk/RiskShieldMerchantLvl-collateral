-- QUERY 4B : PRIOR-DISPUTE preventability tier [MID __MID__]
-- identifier disputed (any merchant) BEFORE the MID-__MID__ disputed txn, within 365d.
WITH tx AS (
    SELECT t.transactionid, CAST(t.cforderid AS VARCHAR) AS cforderid, CAST(t.txtime AS DATE) AS txdate, t.amount AS txn_amt
    FROM cfsellers.cftransactions t
    WHERE t.merchantid = __MID__ AND t.txtime >= date_add('day', -__DAYS__, current_date)
),
disp_on_txn AS (
    SELECT CAST(md.cftxnid AS VARCHAR) AS cftxnid, MAX(md.disputeamount) AS damt
    FROM cfsellers.merchantdisputes md
    WHERE md.merchantid = __MID__ AND md.addedon >= date_add('day', -__DAYS__, current_date)
    GROUP BY 1
),
dtx AS (
    SELECT t.transactionid, t.cforderid, t.txdate, t.txn_amt, d.damt
    FROM tx t JOIN disp_on_txn d ON t.transactionid = d.cftxnid
),
ord_ids AS (
    SELECT d.transactionid, d.txdate, d.damt, d.txn_amt,
           CASE WHEN LENGTH(TRIM(o.customerphone)) = 12 AND TRIM(o.customerphone) LIKE '91%'  THEN SUBSTRING(TRIM(o.customerphone), 3)
                WHEN LENGTH(TRIM(o.customerphone)) = 13 AND TRIM(o.customerphone) LIKE '+91%' THEN SUBSTRING(TRIM(o.customerphone), 4)
                WHEN LENGTH(TRIM(o.customerphone)) = 11 AND TRIM(o.customerphone) LIKE '0%'   THEN SUBSTRING(TRIM(o.customerphone), 2)
                ELSE NULLIF(TRIM(o.customerphone), '') END AS phone,
           LOWER(NULLIF(TRIM(o.customeremail), '')) AS email
    FROM dtx d
    JOIN cfsellers.cforders o ON d.cforderid = CAST(o.id AS VARCHAR)
    WHERE o.merchantid = __MID__ AND o.addedon >= date_add('day', -__SLACK__, current_date)
),
idents AS (
    SELECT transactionid, txdate, damt, txn_amt, 'PHONE' AS idtype, phone AS idvalue FROM ord_ids WHERE phone IS NOT NULL
    UNION ALL SELECT transactionid, txdate, damt, txn_amt, 'EMAIL', email FROM ord_ids WHERE email IS NOT NULL
),
ident_phones AS (SELECT DISTINCT idvalue AS phone FROM idents WHERE idtype = 'PHONE'),
ident_emails AS (SELECT DISTINCT idvalue AS email FROM idents WHERE idtype = 'EMAIL'),
prior_orders AS (
    -- Split the phone-OR-email match into two UNION branches. A single scan with
    -- `phone IN (..) OR email IN (..)` defeats Redshift's hash semi-join (same reason
    -- Q3 is split into Q3A/Q3B); two single-predicate branches each semi-join cleanly.
    SELECT CAST(o2.id AS VARCHAR) AS orderid, o2.merchantid AS d_mid,
           CASE WHEN LENGTH(TRIM(o2.customerphone)) = 12 AND TRIM(o2.customerphone) LIKE '91%'  THEN SUBSTRING(TRIM(o2.customerphone), 3)
                WHEN LENGTH(TRIM(o2.customerphone)) = 13 AND TRIM(o2.customerphone) LIKE '+91%' THEN SUBSTRING(TRIM(o2.customerphone), 4)
                WHEN LENGTH(TRIM(o2.customerphone)) = 11 AND TRIM(o2.customerphone) LIKE '0%'   THEN SUBSTRING(TRIM(o2.customerphone), 2)
                ELSE NULLIF(TRIM(o2.customerphone), '') END AS phone,
           LOWER(NULLIF(TRIM(o2.customeremail), '')) AS email
    FROM cfsellers.cforders o2
    WHERE o2.addedon >= date_add('day', -430, current_date)
      AND NULLIF(TRIM(o2.customerphone),'') IN (SELECT phone FROM ident_phones)
    UNION
    SELECT CAST(o2.id AS VARCHAR) AS orderid, o2.merchantid AS d_mid,
           CASE WHEN LENGTH(TRIM(o2.customerphone)) = 12 AND TRIM(o2.customerphone) LIKE '91%'  THEN SUBSTRING(TRIM(o2.customerphone), 3)
                WHEN LENGTH(TRIM(o2.customerphone)) = 13 AND TRIM(o2.customerphone) LIKE '+91%' THEN SUBSTRING(TRIM(o2.customerphone), 4)
                WHEN LENGTH(TRIM(o2.customerphone)) = 11 AND TRIM(o2.customerphone) LIKE '0%'   THEN SUBSTRING(TRIM(o2.customerphone), 2)
                ELSE NULLIF(TRIM(o2.customerphone), '') END AS phone,
           LOWER(NULLIF(TRIM(o2.customeremail), '')) AS email
    FROM cfsellers.cforders o2
    WHERE o2.addedon >= date_add('day', -430, current_date)
      AND LOWER(NULLIF(TRIM(o2.customeremail),'')) IN (SELECT email FROM ident_emails)
),
prior_mids AS (SELECT DISTINCT d_mid FROM prior_orders),
prior_txns AS (
    SELECT t2.transactionid, CAST(t2.cforderid AS VARCHAR) AS cforderid
    FROM cfsellers.cftransactions t2
    WHERE t2.txtime >= date_add('day', -365, current_date)
      AND t2.merchantid IN (SELECT d_mid FROM prior_mids)
),
prior_disp AS (
    SELECT CAST(md2.cftxnid AS VARCHAR) AS cftxnid, CAST(md2.addedon AS DATE) AS d_date, md2.merchantid AS d_mid
    FROM cfsellers.merchantdisputes md2
    WHERE md2.addedon >= date_add('day', -365, current_date)
      AND md2.merchantid IN (SELECT d_mid FROM prior_mids)
),
prior_disputes AS (
    SELECT po.phone, po.email, pd.d_date, po.d_mid
    FROM prior_orders po
    JOIN prior_txns pt ON pt.cforderid = po.orderid
    JOIN prior_disp pd ON pd.cftxnid = pt.transactionid
),
pd_hits AS (
    SELECT DISTINCT i.transactionid, i.damt, i.txn_amt,
           CASE WHEN pd.d_mid = __MID__ THEN 'PRIOR_DISPUTE_SAME_MID' ELSE 'PRIOR_DISPUTE_CROSS_MID' END AS source,
           i.idtype, i.idvalue, pd.d_date
    FROM idents i
    JOIN prior_disputes pd
      ON ( (i.idtype = 'PHONE' AND pd.phone = i.idvalue)
        OR (i.idtype = 'EMAIL' AND pd.email = i.idvalue) )
    WHERE pd.d_date < i.txdate
),
tot AS (SELECT COUNT(*) AS d_txns, SUM(damt) AS d_amt FROM dtx),
strict AS (SELECT transactionid, MAX(damt) AS damt FROM pd_hits GROUP BY 1),
pd_txn AS (
    SELECT transactionid, MAX(damt) AS damt, MAX(txn_amt) AS txn_amt,
           CASE WHEN source = 'PRIOR_DISPUTE_SAME_MID' THEN 'PRIOR_SAME_MID' ELSE 'PRIOR_CROSS_MID' END AS metric,
           MIN(d_date) AS list_dt
    FROM pd_hits
    GROUP BY transactionid, CASE WHEN source = 'PRIOR_DISPUTE_SAME_MID' THEN 'PRIOR_SAME_MID' ELSE 'PRIOR_CROSS_MID' END
)
SELECT 'TIER' AS section, 'PRIOR_DISPUTE' AS metric, 'LISTED_BEFORE_TXN' AS dim_value,
       CAST(NULL AS DOUBLE PRECISION) AS captured_amt, SUM(damt) AS disputed_amt,
       CAST(NULL AS BIGINT) AS tx_count, COUNT(*) AS dispute_count,
       100.0*SUM(damt)/NULLIF((SELECT d_amt FROM tot),0) AS ratio_pct
FROM strict
UNION ALL
SELECT 'TIER', 'PRIOR_DISPUTE', source, NULL, SUM(damt), NULL, COUNT(DISTINCT transactionid),
       100.0*SUM(damt)/NULLIF((SELECT d_amt FROM tot),0)
FROM (SELECT DISTINCT transactionid, damt, source FROM pd_hits) x GROUP BY source
UNION ALL
SELECT 'TXN', metric, CAST(transactionid AS VARCHAR) || '§' || COALESCE(CAST(list_dt AS VARCHAR),''),
       CAST(txn_amt AS DOUBLE PRECISION), damt, CAST(NULL AS BIGINT), CAST(NULL AS BIGINT), CAST(NULL AS DOUBLE PRECISION)
FROM pd_txn
ORDER BY metric, dim_value;
