-- QUERY 2 : MERCHANT DISPUTE REPORT (last 180 days)  [Risk Desk - Redshift-adapted]
WITH tx AS (
    SELECT t.transactionid, CAST(t.cforderid AS VARCHAR) AS cforderid,
           t.capturedamount, t.txstatus,
           NULLIF(TRIM(t.paymentmode), '') AS paymentmode,
           NULLIF(TRIM(t.cardnumber), '') AS cardnumber,
           NULLIF(TRIM(t.sessionid), '')  AS ip,
           CAST(t.txtime AS DATE) AS txdate
    FROM cfsellers.cftransactions t
    WHERE t.merchantid = __MID__ AND t.txtime >= date_add('day', -__DAYS__, current_date)
),
tsr AS (
    SELECT s.transactionid,
           MAX(NULLIF(TRIM(s.svpa), ''))    AS svpa,
           MAX(NULLIF(TRIM(s.spar), ''))    AS spar,
           MAX(NULLIF(TRIM(s.cardbin), '')) AS cardbin,
           MAX(UPPER(NULLIF(TRIM(s.proxytype), ''))) AS proxytype,
           MAX(NULLIF(TRIM(s.sip), ''))     AS sip
    FROM shield.txnscreenedresult s
    WHERE s.merchantid = '__MID__' AND s.product = 'PG'
      AND s.addedon >= date_add('day', -__DAYS__, current_date)
    GROUP BY s.transactionid
),
txe AS (
    SELECT t.*, s.svpa, s.spar, s.cardbin, s.proxytype, COALESCE(t.ip, s.sip) AS ip2
    FROM tx t LEFT JOIN tsr s ON t.transactionid = s.transactionid
),
disp_raw AS (
    SELECT CAST(md.cftxnid AS VARCHAR) AS cftxnid, md.disputeamount,
           UPPER(NULLIF(TRIM(md.type), ''))   AS dtype,
           NULLIF(TRIM(CAST(md.reason AS VARCHAR)), '') AS reasoncode,   -- merchantdisputes.reason already carries "code-description" text
           UPPER(NULLIF(TRIM(md.status), '')) AS dstatus,
           md.addedon AS disputedon
    FROM cfsellers.merchantdisputes md
    WHERE md.merchantid = __MID__ AND md.addedon >= date_add('day', -__DAYS__, current_date)
),
disp_pick AS (   -- ONE row per txn: the dispute row with the largest amount (DISPUTE->CHARGEBACK escalation is one loss).
                 -- This is the consistency guard so every anatomy split sums back to the headline disputed amount.
    SELECT cftxnid, disputeamount AS damt, dtype, reasoncode, dstatus, disputedon
    FROM (
        SELECT dr.*, ROW_NUMBER() OVER (PARTITION BY cftxnid ORDER BY disputeamount DESC NULLS LAST, disputedon DESC) AS rn
        FROM disp_raw dr
    ) x WHERE rn = 1
),
disp_on_txn AS (SELECT cftxnid, damt, 1 AS dcnt FROM disp_pick),
dispe AS (
    SELECT t.*, d.damt, d.dcnt FROM txe t JOIN disp_on_txn d ON t.transactionid = d.cftxnid
),
dispf AS (   -- disputed txns with per-txn dispute anatomy attributes (from disp_pick)
    SELECT t.*, p.damt, p.dtype, p.reasoncode, p.dstatus, p.disputedon
    FROM txe t JOIN disp_pick p ON t.transactionid = p.cftxnid
),
d_by_mode AS (
    SELECT COALESCE(paymentmode, '(unknown)') AS k, SUM(damt) AS damt, COUNT(*) AS dcnt
    FROM dispf GROUP BY 1
),
d_by_type AS (
    SELECT COALESCE(dtype, '(none)') AS k, SUM(damt) AS damt, COUNT(*) AS dcnt
    FROM dispf GROUP BY 1
),
d_by_reason_raw AS (
    SELECT COALESCE(reasoncode, '(none)') AS reasoncode, SUM(damt) AS damt, COUNT(*) AS dcnt
    FROM dispf GROUP BY 1
),
d_by_reason AS (
    -- top 8 reasons by disputed amount; everything else folds into OTHER.
    -- merchantdisputes.reason already holds the full "code-description" text, so use it directly as the label.
    SELECT r.reasoncode,
           r.reasoncode AS label,
           r.damt, r.dcnt,
           ROW_NUMBER() OVER (ORDER BY r.damt DESC NULLS LAST) AS rnk
    FROM d_by_reason_raw r
),
d_by_reason_top AS (
    SELECT label AS k, damt, dcnt FROM d_by_reason WHERE rnk <= 8
    UNION ALL
    SELECT 'OTHER (' || CAST(COUNT(*) AS VARCHAR) || ' reasons)' AS k, SUM(damt) AS damt, SUM(dcnt) AS dcnt
    FROM d_by_reason WHERE rnk > 8
    HAVING COUNT(*) > 0
),
d_outcome AS (
    SELECT CASE
             WHEN dstatus = 'MERCHANT_WON'      THEN 'WON'
             WHEN dstatus = 'MERCHANT_LOST'     THEN 'LOST'
             WHEN dstatus = 'MERCHANT_ACCEPTED' THEN 'ACCEPTED'
             WHEN dstatus = 'REJECTED'          THEN 'REJECTED'
             WHEN dstatus IN ('NEW','DOC_RECEIVED','CONTESTED','NEED_MORE_DOCS') THEN 'OPEN'
             ELSE 'OTHER'
           END AS bucket,
           SUM(damt) AS damt, COUNT(*) AS dcnt
    FROM dispf GROUP BY 1
),
days_kpi AS (   -- P0-3 fix (§5.8): expose population sizes + a like-for-like (charged-back) timing,
                -- and count txn>dispute ordering violations so the report never presents chargeback-days < dispute-days
                -- as if the two averages covered the same population.
    SELECT AVG(datediff(day, txdate, CAST(disputedon AS DATE)) * 1.0) AS avg_days_dispute,
           COUNT(*) AS disp_pop,
           AVG(CASE WHEN dtype IN ('CHARGEBACK','PRE_ARBITRATION','ARBITRATION')
                    THEN datediff(day, txdate, CAST(disputedon AS DATE)) * 1.0 END) AS avg_days_dispute_cbpop,
           AVG(CASE WHEN dtype IN ('CHARGEBACK','PRE_ARBITRATION','ARBITRATION')
                    THEN datediff(day, txdate, CAST(disputedon AS DATE)) * 1.0 END) AS avg_days_cb,
           SUM(CASE WHEN dtype IN ('CHARGEBACK','PRE_ARBITRATION','ARBITRATION') THEN 1 ELSE 0 END) AS cb_pop,
           SUM(CASE WHEN datediff(day, txdate, CAST(disputedon AS DATE)) < 0 THEN 1 ELSE 0 END) AS neg_order_violations
    FROM dispf
),
reason_grp AS (   -- §5.6 reason-code map -> dispute group (fraud-coded share drives 25% of the verdict).
                  -- merchantdisputes.reason carries "code-description"; pull the leading numeric code.
    SELECT CASE
             WHEN REGEXP_SUBSTR(COALESCE(reasoncode,''), '[0-9]+') IN ('1401','128')               THEN 'FRAUD'
             WHEN REGEXP_SUBSTR(COALESCE(reasoncode,''), '[0-9]+') IN ('1403','1064','1065','1061') THEN 'SERVICE'
             WHEN REGEXP_SUBSTR(COALESCE(reasoncode,''), '[0-9]+') = '1084'                         THEN 'PROCESS'
             WHEN REGEXP_SUBSTR(COALESCE(reasoncode,''), '[0-9]+') = '4853'                         THEN 'CONDITIONAL_4853'
             WHEN reasoncode IS NULL                                                                THEN 'UNCODED'
             ELSE 'UNMAPPED'
           END AS grp,
           SUM(damt) AS damt, COUNT(*) AS dcnt
    FROM dispf GROUP BY 1
),
par_card AS (   -- PAR (shield.txnscreenedresult.spar) is the true card identity; one hashed cardnumber can map to >1 PAR.
                -- We key card sources on PAR and carry a representative hashed cardnumber for display only.
    SELECT spar, MAX(cardnumber) AS cardnumber
    FROM txe
    WHERE spar IS NOT NULL AND cardnumber IS NOT NULL AND cardnumber NOT LIKE '%@%'   -- exclude UPI VPAs (handled as UPI_VPA)
    GROUP BY spar
),
ord AS (
    SELECT d.transactionid,
           CASE WHEN LENGTH(TRIM(o.customerphone)) = 12 AND TRIM(o.customerphone) LIKE '91%'  THEN SUBSTRING(TRIM(o.customerphone), 3)
                WHEN LENGTH(TRIM(o.customerphone)) = 13 AND TRIM(o.customerphone) LIKE '+91%' THEN SUBSTRING(TRIM(o.customerphone), 4)
                WHEN LENGTH(TRIM(o.customerphone)) = 11 AND TRIM(o.customerphone) LIKE '0%'   THEN SUBSTRING(TRIM(o.customerphone), 2)
                ELSE NULLIF(TRIM(o.customerphone), '') END AS phone,
           NULLIF(TRIM(o.customeremail), '') AS email
    FROM dispe d
    JOIN cfsellers.cforders o
      ON d.cforderid = CAST(o.id AS VARCHAR)
    WHERE o.merchantid = __MID__
      AND o.addedon >= date_add('day', -__SLACK__, current_date)
),
weekly_cap AS (
    SELECT date_trunc('week', txdate) AS wk, SUM(capturedamount) AS cap, COUNT(*) AS txns
    FROM txe WHERE txstatus = 'SUCCESS' GROUP BY 1
),
weekly_disp AS (
    SELECT date_trunc('week', txdate) AS wk, SUM(damt) AS damt, SUM(dcnt) AS dcnt FROM dispe GROUP BY 1
),
cap_by_id AS (
    SELECT idtype, idvalue, SUM(capturedamount) AS cap, COUNT(*) AS txns FROM (
        SELECT 'CARD_PAR' AS idtype, spar AS idvalue, capturedamount FROM txe WHERE txstatus='SUCCESS' AND spar IS NOT NULL
        UNION ALL SELECT 'UPI_VPA', svpa, capturedamount FROM txe WHERE txstatus='SUCCESS' AND svpa IS NOT NULL
        UNION ALL SELECT 'CARD_BIN', cardbin, capturedamount FROM txe WHERE txstatus='SUCCESS' AND cardbin IS NOT NULL
        UNION ALL SELECT 'IP_NON_DCH', ip2, capturedamount FROM txe WHERE txstatus='SUCCESS' AND ip2 IS NOT NULL AND COALESCE(proxytype,'') <> 'DCH'
    ) u GROUP BY 1, 2
),
disp_by_id AS (
    SELECT idtype, idvalue, SUM(damt) AS damt, SUM(dcnt) AS dcnt FROM (
        SELECT 'CARD_PAR' AS idtype, spar AS idvalue, damt, dcnt FROM dispe WHERE spar IS NOT NULL
        UNION ALL SELECT 'UPI_VPA', svpa, damt, dcnt FROM dispe WHERE svpa IS NOT NULL
        UNION ALL SELECT 'CARD_BIN', cardbin, damt, dcnt FROM dispe WHERE cardbin IS NOT NULL
        UNION ALL SELECT 'IP_NON_DCH', ip2, damt, dcnt FROM dispe WHERE ip2 IS NOT NULL AND COALESCE(proxytype,'') <> 'DCH'
    ) u GROUP BY 1, 2
),
top_sources AS (   -- §5.3: rank by disputed amount; eligibility = captured>=5000 OR txns>=3 OR disputes>=2.
                   -- Raw ratio can exceed 100% (a txn disputed but not SUCCESS-captured contributes damt but
                   -- not cap); the REPORT layer caps ratio via min(disp,cap)/cap and routes disp>cap rows to
                   -- Appendix D. We emit the raw cap/disp/txns/disputes so the report can do that transparently.
    SELECT idtype, idvalue, cap, damt, txns, dcnt, ratio_pct FROM (
        SELECT c.idtype, c.idvalue, c.cap, COALESCE(d.damt,0) AS damt, c.txns, COALESCE(d.dcnt,0) AS dcnt,
               100.0 * COALESCE(d.damt,0) / NULLIF(c.cap,0) AS ratio_pct,
               ROW_NUMBER() OVER (ORDER BY COALESCE(d.damt,0) DESC NULLS LAST) AS rn
        FROM cap_by_id c
        LEFT JOIN disp_by_id d ON c.idtype = d.idtype AND c.idvalue = d.idvalue
        WHERE COALESCE(d.damt,0) > 0
          AND (c.cap >= 5000 OR c.txns >= 3 OR COALESCE(d.dcnt,0) >= 2)
    ) z WHERE rn <= 150
),
proxy_pct AS (   -- P0-4 fix (§5.4/§5.9): proxytype is known ONLY for Risk-Shield-screened txns, so TOR/VPN %
                 -- must be computed over the SCREENED disputed population, with coverage exposed so the report
                 -- can suppress the metric when coverage < 10%.
    SELECT COUNT(*) AS disputed_txns,
           SUM(CASE WHEN proxytype IS NOT NULL THEN 1 ELSE 0 END) AS screened_txns,
           SUM(CASE WHEN proxytype = 'TOR' THEN 1 ELSE 0 END) AS tor_cnt,
           SUM(CASE WHEN proxytype LIKE '%VPN%' THEN 1 ELSE 0 END) AS vpn_cnt
    FROM dispe
),
lists AS (
    -- FYI counts only. Q3 is self-contained now, so we no longer emit paste-lists.
    -- (Redshift rejects LISTAGG alongside COUNT(DISTINCT) in the same SELECT.)
    SELECT 'PHONES' AS k, COUNT(DISTINCT phone) AS n FROM ord WHERE phone IS NOT NULL
    UNION ALL SELECT 'EMAILS', COUNT(DISTINCT email) FROM ord WHERE email IS NOT NULL
    UNION ALL SELECT 'VPAS', COUNT(DISTINCT svpa) FROM dispe WHERE svpa IS NOT NULL
    UNION ALL SELECT 'CARD_PARS', COUNT(DISTINCT spar) FROM dispe WHERE spar IS NOT NULL
    UNION ALL SELECT 'CARD_BINS', COUNT(DISTINCT cardbin) FROM dispe WHERE cardbin IS NOT NULL
    UNION ALL SELECT 'IPS', COUNT(DISTINCT ip2) FROM dispe WHERE ip2 IS NOT NULL
)
SELECT 'WEEKLY' AS section, 'WOW_DISPUTE_RATE' AS metric, CAST(c.wk AS VARCHAR) AS dim_value,
       c.cap AS captured_amt, COALESCE(d.damt,0) AS disputed_amt,
       c.txns AS tx_count, COALESCE(d.dcnt,0) AS dispute_count,
       100.0*COALESCE(d.damt,0)/NULLIF(c.cap,0) AS ratio_pct
FROM weekly_cap c LEFT JOIN weekly_disp d ON c.wk = d.wk
UNION ALL SELECT 'TOP_SRC', ts.idtype,
       CASE WHEN ts.idtype = 'CARD_PAR'   -- show hashed cardnumber to the reader, but the row is one PAR
            THEN COALESCE(pc.cardnumber, '(card n/a)') || '§' || ts.idvalue
            ELSE ts.idvalue END,
       ts.cap, ts.damt, ts.txns, ts.dcnt, ts.ratio_pct
  FROM top_sources ts LEFT JOIN par_card pc ON ts.idtype = 'CARD_PAR' AND ts.idvalue = pc.spar
UNION ALL SELECT 'DSPLIT','BY_PAYMENTMODE', k, NULL, damt, NULL, dcnt, NULL FROM d_by_mode
UNION ALL SELECT 'DSPLIT','BY_TYPE',        k, NULL, damt, NULL, dcnt, NULL FROM d_by_type
UNION ALL SELECT 'DSPLIT','BY_REASON',      k, NULL, damt, NULL, dcnt, NULL FROM d_by_reason_top
UNION ALL SELECT 'DOUTCOME', bucket, 'ALL', NULL, damt, NULL, dcnt, NULL FROM d_outcome
UNION ALL SELECT 'DGROUP', grp, 'ALL', NULL, damt, NULL, dcnt, NULL FROM reason_grp
UNION ALL SELECT 'DKPI','AVG_DAYS_TO_DISPUTE',       'ALL', NULL, NULL, disp_pop, NULL,                 avg_days_dispute       FROM days_kpi
UNION ALL SELECT 'DKPI','AVG_DAYS_TO_DISPUTE_CBPOP', 'ALL', NULL, NULL, cb_pop,   NULL,                 avg_days_dispute_cbpop FROM days_kpi
UNION ALL SELECT 'DKPI','AVG_DAYS_TO_CHARGEBACK',    'ALL', NULL, NULL, cb_pop,   NULL,                 avg_days_cb            FROM days_kpi
UNION ALL SELECT 'DKPI','TIMING_ORDER_VIOLATIONS',   'ALL', NULL, NULL, disp_pop, neg_order_violations, NULL                   FROM days_kpi
UNION ALL SELECT 'PROXY','TOR_PCT_OF_SCREENED_TXNS','ALL',NULL,NULL,screened_txns,tor_cnt,100.0*tor_cnt/NULLIF(screened_txns,0) FROM proxy_pct
UNION ALL SELECT 'PROXY','VPN_PCT_OF_SCREENED_TXNS','ALL',NULL,NULL,screened_txns,vpn_cnt,100.0*vpn_cnt/NULLIF(screened_txns,0) FROM proxy_pct
UNION ALL SELECT 'PROXY','SCREENED_COVERAGE','ALL',NULL,NULL,disputed_txns,screened_txns,100.0*screened_txns/NULLIF(disputed_txns,0) FROM proxy_pct
UNION ALL SELECT 'NOTE','PINCODE_RATIO','Not derivable: no pincode column in provided tables',NULL,NULL,NULL,NULL,NULL
UNION ALL SELECT 'PASTE_LIST','PASTE_LIST_'||k,'(count only - Q3 self-contained)',NULL,NULL,n,NULL,NULL FROM lists
ORDER BY section, metric, dim_value, disputed_amt DESC NULLS LAST;
