-- Q4D ML-MODEL + IP=DCH + MIN-SR fallback [MID __MID__]  (all MID-local, fast)
WITH win_tx AS (          -- every MID txn in the window
    SELECT CAST(t.transactionid AS VARCHAR) AS transactionid,
           CAST(t.cforderid AS VARCHAR) AS cforderid,
           CAST(t.txtime AS DATE) AS txdate, t.amount AS txn_amt,
           t.txstatus, t.paymentmode,
           CASE WHEN t.cardnumber LIKE '%@%' THEN LOWER(NULLIF(TRIM(t.cardnumber), '')) END AS vpa
    FROM cfsellers.cftransactions t
    WHERE t.merchantid = __MID__ AND t.txtime >= date_add('day', -__DAYS__, current_date)),
disp AS (
    SELECT CAST(md.cftxnid AS VARCHAR) AS cftxnid, MAX(md.disputeamount) AS damt
    FROM cfsellers.merchantdisputes md
    WHERE md.merchantid = __MID__ AND md.addedon >= date_add('day', -__DAYS__, current_date) GROUP BY 1),
dtx AS (                  -- disputed MID txns
    SELECT w.transactionid, w.cforderid, w.txdate, w.txn_amt, w.vpa, d.damt
    FROM win_tx w JOIN disp d ON d.cftxnid = w.transactionid),
-- ML risk score per txn (PG model; entityid = merchantid)
osr AS (
    SELECT CAST(o.transactionid AS VARCHAR) AS transactionid, MAX(o.riskscore) AS riskscore
    FROM shield.observationscreeningresult o
    WHERE o.entityid = CAST(__MID__ AS VARCHAR) AND o.product = 'PG'
      AND o.addedon >= date_add('day', -__DAYS__, current_date)
    GROUP BY 1),
-- model quality over SUCCESS card txns (mirrors the OB_PG_ML_MODEL evaluation basis)
ml_base AS (
    SELECT w.transactionid,
           CASE WHEN o.riskscore >= 0.5 THEN 1 ELSE 0 END AS prediction,
           CASE WHEN d.cftxnid IS NOT NULL THEN 1 ELSE 0 END AS is_disputed
    FROM win_tx w
    JOIN osr o ON o.transactionid = w.transactionid
    LEFT JOIN disp d ON d.cftxnid = w.transactionid
    WHERE w.txstatus = 'SUCCESS'
      AND w.paymentmode LIKE '%CARD%' AND w.paymentmode NOT LIKE '%UPI%'),
mlstat AS (
    SELECT SUM(CASE WHEN prediction=1 AND is_disputed=1 THEN 1 ELSE 0 END) AS tp,
           SUM(CASE WHEN prediction=1 AND is_disputed=0 THEN 1 ELSE 0 END) AS fp,
           SUM(CASE WHEN prediction=0 AND is_disputed=1 THEN 1 ELSE 0 END) AS fn
    FROM ml_base),
ml_txn AS (               -- disputed txns the model would have flagged
    SELECT dt.transactionid, dt.txn_amt, dt.damt, o.riskscore
    FROM dtx dt JOIN osr o ON o.transactionid = dt.transactionid
    WHERE o.riskscore >= 0.5),
-- IP = data-center-hosting proxy (per-txn attribute)
dch AS (
    SELECT DISTINCT CAST(tsr.transactionid AS VARCHAR) AS transactionid
    FROM shield.txnscreenedresult tsr
    WHERE tsr.merchantid = __MID__ AND tsr.proxytype = 'DCH'
      AND tsr.addedon >= date_add('day', -__DAYS__, current_date)),
dch_txn AS (
    SELECT dt.transactionid, dt.txn_amt, dt.damt
    FROM dtx dt JOIN dch ON dch.transactionid = dt.transactionid),
-- PAR per txn (source card PAR, unhashed)
tx_par AS (
    SELECT CAST(tsr.transactionid AS VARCHAR) AS transactionid,
           MAX(LOWER(NULLIF(TRIM(tsr.spar), ''))) AS par
    FROM shield.txnscreenedresult tsr
    WHERE tsr.merchantid = __MID__ AND tsr.addedon >= date_add('day', -__DAYS__, current_date)
      AND NULLIF(TRIM(tsr.spar), '') IS NOT NULL
    GROUP BY 1),
-- phone/email/vpa per MID txn (for Min-SR)
tx_ord AS (
    SELECT w.transactionid, w.txstatus, w.vpa,
           CASE WHEN LENGTH(TRIM(o.customerphone)) = 12 AND TRIM(o.customerphone) LIKE '91%'  THEN SUBSTRING(TRIM(o.customerphone), 3)
                WHEN LENGTH(TRIM(o.customerphone)) = 13 AND TRIM(o.customerphone) LIKE '+91%' THEN SUBSTRING(TRIM(o.customerphone), 4)
                WHEN LENGTH(TRIM(o.customerphone)) = 11 AND TRIM(o.customerphone) LIKE '0%'   THEN SUBSTRING(TRIM(o.customerphone), 2)
                ELSE NULLIF(TRIM(o.customerphone), '') END AS phone,
           LOWER(NULLIF(TRIM(o.customeremail), '')) AS email
    FROM win_tx w
    LEFT JOIN cfsellers.cforders o
      ON w.cforderid = CAST(o.id AS VARCHAR) AND o.merchantid = __MID__
     AND o.addedon >= date_add('day', -__SLACK__, current_date)),
tx_ident AS (
    SELECT transactionid, txstatus, 'PHONE' AS idtype, phone AS idvalue FROM tx_ord WHERE phone IS NOT NULL
    UNION ALL SELECT transactionid, txstatus, 'EMAIL', email FROM tx_ord WHERE email IS NOT NULL
    UNION ALL SELECT transactionid, txstatus, 'VPA', vpa FROM tx_ord WHERE vpa IS NOT NULL
    UNION ALL SELECT w.transactionid, w.txstatus, 'PAR', p.par
              FROM tx_par p JOIN win_tx w ON w.transactionid = p.transactionid),
sr_ident AS (
    SELECT idtype, idvalue,
           SUM(CASE WHEN txstatus = 'SUCCESS' THEN 1 ELSE 0 END) AS succ,
           SUM(CASE WHEN txstatus IN ('SUCCESS','FAILED','USER_DROPPED') THEN 1 ELSE 0 END) AS denom
    FROM tx_ident GROUP BY idtype, idvalue),
dtx_ident AS (
    SELECT ti.transactionid, ti.idtype, ti.idvalue
    FROM tx_ident ti JOIN dtx dt ON dt.transactionid = ti.transactionid),
sr_rank AS (
    SELECT di.transactionid, s.idtype, s.idvalue,
           100.0*s.succ/NULLIF(s.denom,0) AS sr,
           ROW_NUMBER() OVER (PARTITION BY di.transactionid
                              ORDER BY 100.0*s.succ/NULLIF(s.denom,0) ASC, s.denom DESC) AS rn
    FROM dtx_ident di JOIN sr_ident s ON s.idtype = di.idtype AND s.idvalue = di.idvalue
    WHERE s.denom > 0),
sr_min AS (SELECT transactionid, idtype, idvalue, sr FROM sr_rank WHERE rn = 1)
SELECT 'MLSTAT' AS section, 'ML' AS metric, 'SUMMARY' AS dim_value,
       CAST(tp AS DOUBLE PRECISION) AS captured_amt, CAST(fp AS DOUBLE PRECISION) AS disputed_amt,
       CAST(NULL AS BIGINT) AS tx_count, CAST(fn AS BIGINT) AS dispute_count,
       CAST(NULL AS DOUBLE PRECISION) AS ratio_pct
FROM mlstat
UNION ALL
SELECT 'TXN','ML_MODEL', CAST(transactionid AS VARCHAR) || '§' || COALESCE(CAST(ROUND(riskscore,4) AS VARCHAR),''),
       CAST(txn_amt AS DOUBLE PRECISION), damt, CAST(NULL AS BIGINT), CAST(NULL AS BIGINT), CAST(NULL AS DOUBLE PRECISION)
FROM ml_txn
UNION ALL
SELECT 'TXN','DCH', CAST(transactionid AS VARCHAR) || '§',
       CAST(txn_amt AS DOUBLE PRECISION), damt, CAST(NULL AS BIGINT), CAST(NULL AS BIGINT), CAST(NULL AS DOUBLE PRECISION)
FROM dch_txn
UNION ALL
SELECT 'TXN','SR', CAST(sm.transactionid AS VARCHAR) || '§' || sm.idtype || '§' || sm.idvalue,
       CAST(dt.txn_amt AS DOUBLE PRECISION), dt.damt, CAST(NULL AS BIGINT), CAST(NULL AS BIGINT),
       CAST(sm.sr AS DOUBLE PRECISION)
FROM sr_min sm JOIN dtx dt ON dt.transactionid = sm.transactionid;
