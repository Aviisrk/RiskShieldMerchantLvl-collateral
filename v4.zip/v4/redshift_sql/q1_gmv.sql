-- QUERY 1 : MERCHANT GMV REPORT (last 180 days)  [Risk Desk - optimized: txtime, int mid, no col CAST]
WITH tx AS (
    SELECT t.paymentmode, t.capturedamount
    FROM cfsellers.cftransactions t
    WHERE t.merchantid = __MID__
      AND t.txtime >= date_add('day', -__DAYS__, current_date)
      AND t.txstatus = 'SUCCESS'
),
ord AS (
    SELECT NULLIF(TRIM(o.customeremail), '') AS email,
           NULLIF(TRIM(o.customerphone), '') AS phone,
           date_trunc('month', o.addedon) AS mth
    FROM cfsellers.cforders o
    WHERE o.merchantid = __MID__
      AND o.addedon >= date_add('day', -__DAYS__, current_date)
),
total_captured AS (SELECT SUM(capturedamount) AS amt, COUNT(*) AS cnt FROM tx),
mode_split AS (
    SELECT COALESCE(paymentmode,'(null)') AS pmode, SUM(capturedamount) AS amt, COUNT(*) AS cnt
    FROM tx GROUP BY 1
),
email_monthly AS (SELECT email, mth, COUNT(*) AS c FROM ord WHERE email IS NOT NULL GROUP BY 1,2),
phone_monthly AS (SELECT phone, mth, COUNT(*) AS c FROM ord WHERE phone IS NOT NULL GROUP BY 1,2),
dummy_emails AS (SELECT email, SUM(c) AS total_txns FROM email_monthly GROUP BY email HAVING MAX(c) > 2000),
dummy_phones AS (SELECT phone, SUM(c) AS total_txns FROM phone_monthly GROUP BY phone HAVING MAX(c) > 2000),
email_count AS (
    SELECT COUNT(*) AS c
    FROM (SELECT DISTINCT email FROM ord WHERE email IS NOT NULL) e
    LEFT JOIN dummy_emails d ON e.email = d.email WHERE d.email IS NULL
),
phone_count AS (
    SELECT COUNT(*) AS c
    FROM (SELECT DISTINCT phone FROM ord WHERE phone IS NOT NULL) e
    LEFT JOIN dummy_phones d ON e.phone = d.phone WHERE d.phone IS NULL
)
SELECT 'GMV' AS section, 'TOTAL_CAPTURED_180D' AS metric, 'ALL' AS dim_value,
       amt AS captured_amt, CAST(NULL AS DOUBLE PRECISION) AS disputed_amt,
       cnt AS tx_count, CAST(NULL AS BIGINT) AS dispute_count, CAST(NULL AS DOUBLE PRECISION) AS ratio_pct
FROM total_captured
UNION ALL SELECT 'GMV','CAPTURED_BY_PAYMENTMODE',pmode,amt,NULL,cnt,NULL,NULL FROM mode_split
UNION ALL SELECT 'IDENTIFIERS','DISTINCT_EMAILS_EX_DUMMY','ALL',NULL,NULL,c,NULL,NULL FROM email_count
UNION ALL SELECT 'IDENTIFIERS','DISTINCT_PHONES_EX_DUMMY','ALL',NULL,NULL,c,NULL,NULL FROM phone_count
UNION ALL SELECT 'IDENTIFIERS','DUMMY_EMAIL',email,NULL,NULL,total_txns,NULL,NULL FROM dummy_emails
UNION ALL SELECT 'IDENTIFIERS','DUMMY_PHONE',phone,NULL,NULL,total_txns,NULL,NULL FROM dummy_phones
ORDER BY section, metric, captured_amt DESC NULLS LAST, tx_count DESC NULLS LAST;
