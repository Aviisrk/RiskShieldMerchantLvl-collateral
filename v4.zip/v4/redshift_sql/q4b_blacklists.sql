-- Q4 CF_BLACKLIST + MERCHANT_BLACKLIST tiers [MID __MID__]
WITH tx AS (
    SELECT t.transactionid, CAST(t.cforderid AS VARCHAR) AS cforderid, CAST(t.txtime AS DATE) AS txdate,
           t.amount AS txn_amt,
           CASE WHEN t.cardnumber LIKE '%@%' THEN LOWER(NULLIF(TRIM(t.cardnumber), '')) END AS vpa
    FROM cfsellers.cftransactions t
    WHERE t.merchantid = __MID__ AND t.txtime >= date_add('day', -__DAYS__, current_date)),
disp_on_txn AS (
    SELECT CAST(md.cftxnid AS VARCHAR) AS cftxnid, MAX(md.disputeamount) AS damt
    FROM cfsellers.merchantdisputes md
    WHERE md.merchantid = __MID__ AND md.addedon >= date_add('day', -__DAYS__, current_date) GROUP BY 1),
dtx AS (SELECT t.transactionid, t.cforderid, t.txdate, t.txn_amt, t.vpa, d.damt FROM tx t JOIN disp_on_txn d ON t.transactionid = d.cftxnid),
ord_ids AS (
    SELECT d.transactionid, d.txdate, d.damt, d.txn_amt, d.vpa,
       CASE WHEN LENGTH(TRIM(o.customerphone)) = 12 AND TRIM(o.customerphone) LIKE '91%'  THEN SUBSTRING(TRIM(o.customerphone), 3)
            WHEN LENGTH(TRIM(o.customerphone)) = 13 AND TRIM(o.customerphone) LIKE '+91%' THEN SUBSTRING(TRIM(o.customerphone), 4)
            WHEN LENGTH(TRIM(o.customerphone)) = 11 AND TRIM(o.customerphone) LIKE '0%'   THEN SUBSTRING(TRIM(o.customerphone), 2)
            ELSE NULLIF(TRIM(o.customerphone), '') END AS phone,
       LOWER(NULLIF(TRIM(o.customeremail), '')) AS email
    FROM dtx d JOIN cfsellers.cforders o ON d.cforderid = CAST(o.id AS VARCHAR)
    WHERE o.merchantid = __MID__ AND o.addedon >= date_add('day', -__SLACK__, current_date)),
idents AS (
    SELECT transactionid, txdate, damt, txn_amt, 'PHONE' AS idtype, phone AS idvalue FROM ord_ids WHERE phone IS NOT NULL
    UNION ALL SELECT transactionid, txdate, damt, txn_amt, 'EMAIL', email FROM ord_ids WHERE email IS NOT NULL
    UNION ALL SELECT transactionid, txdate, damt, txn_amt, 'VPA', vpa FROM ord_ids WHERE vpa IS NOT NULL),
-- pre-normalise + filter the small blacklist tables to only rows matching our identifiers
cfbl AS (
    SELECT CASE WHEN LOWER(blacklisttype) IN ('phoneno','phone','mobile') THEN 'PHONE'
                WHEN LOWER(blacklisttype) = 'email' THEN 'EMAIL'
                WHEN LOWER(blacklisttype) = 'vpa' THEN 'VPA' ELSE 'OTHER' END AS idtype,
           CASE WHEN LOWER(blacklisttype) IN ('email','vpa') THEN LOWER(TRIM(blacklisttypevalue))
                WHEN LENGTH(TRIM(blacklisttypevalue)) = 12 AND TRIM(blacklisttypevalue) LIKE '91%'  THEN SUBSTRING(TRIM(blacklisttypevalue), 3)
                WHEN LENGTH(TRIM(blacklisttypevalue)) = 13 AND TRIM(blacklisttypevalue) LIKE '+91%' THEN SUBSTRING(TRIM(blacklisttypevalue), 4)
                WHEN LENGTH(TRIM(blacklisttypevalue)) = 11 AND TRIM(blacklisttypevalue) LIKE '0%'   THEN SUBSTRING(TRIM(blacklisttypevalue), 2)
                ELSE NULLIF(TRIM(blacklisttypevalue), '') END AS idvalue,
           CAST(addedon AS DATE) AS dt
    FROM shield.riskblacklisteditems
    WHERE isactive = 1 AND LOWER(blacklisttype) IN ('phoneno','phone','mobile','email','vpa')),
mr AS (
    SELECT CASE WHEN UPPER(TRIM(field)) IN ('MOBILE','PHONE') THEN 'PHONE'
                WHEN UPPER(TRIM(field)) = 'EMAIL' THEN 'EMAIL'
                WHEN UPPER(TRIM(field)) = 'VPA' THEN 'VPA' ELSE 'OTHER' END AS idtype,
           CASE WHEN UPPER(TRIM(field)) IN ('EMAIL','VPA') THEN LOWER(TRIM(value))
                WHEN LENGTH(TRIM(value)) = 12 AND TRIM(value) LIKE '91%'  THEN SUBSTRING(TRIM(value), 3)
                WHEN LENGTH(TRIM(value)) = 13 AND TRIM(value) LIKE '+91%' THEN SUBSTRING(TRIM(value), 4)
                WHEN LENGTH(TRIM(value)) = 11 AND TRIM(value) LIKE '0%'   THEN SUBSTRING(TRIM(value), 2)
                ELSE NULLIF(TRIM(value), '') END AS idvalue,
           CAST(addedon AS DATE) AS dt
    FROM shield.merchant_rule
    WHERE ruletype = 'BLACKLIST' AND status = 1 AND UPPER(TRIM(field)) IN ('MOBILE','PHONE','EMAIL','VPA')),
cfbl_hits AS (
    SELECT DISTINCT i.transactionid, i.damt, i.txn_amt,
           MAX(CASE WHEN b.dt <= i.txdate THEN 1 ELSE 0 END) AS before_f,
           MIN(CASE WHEN b.dt <= i.txdate THEN b.dt END) AS list_dt
    FROM idents i JOIN cfbl b ON b.idtype = i.idtype AND b.idvalue = i.idvalue
    GROUP BY i.transactionid, i.damt, i.txn_amt),
mr_hits AS (
    SELECT DISTINCT i.transactionid, i.damt, i.txn_amt,
           MAX(CASE WHEN m.dt <= i.txdate THEN 1 ELSE 0 END) AS before_f,
           MIN(CASE WHEN m.dt <= i.txdate THEN m.dt END) AS list_dt
    FROM idents i JOIN mr m ON m.idtype = i.idtype AND m.idvalue = i.idvalue
    GROUP BY i.transactionid, i.damt, i.txn_amt),
tot AS (SELECT COUNT(*) AS d_txns, SUM(damt) AS d_amt FROM dtx),
cfbl_d AS (SELECT transactionid, MAX(damt) AS damt, MAX(txn_amt) AS txn_amt, MAX(before_f) AS bf, MIN(list_dt) AS list_dt FROM cfbl_hits GROUP BY transactionid),
mr_d   AS (SELECT transactionid, MAX(damt) AS damt, MAX(txn_amt) AS txn_amt, MAX(before_f) AS bf, MIN(list_dt) AS list_dt FROM mr_hits   GROUP BY transactionid)
SELECT 'TIER' AS section, 'CF_BLACKLIST' AS metric, 'EVER_LISTED' AS dim_value,
       CAST(NULL AS DOUBLE PRECISION) AS captured_amt, SUM(damt) AS disputed_amt,
       CAST(NULL AS BIGINT) AS tx_count, COUNT(DISTINCT transactionid) AS dispute_count,
       100.0*SUM(damt)/NULLIF((SELECT d_amt FROM tot),0) AS ratio_pct
FROM cfbl_d
UNION ALL
SELECT 'TIER','CF_BLACKLIST','LISTED_BEFORE_TXN', NULL, SUM(damt), NULL, COUNT(DISTINCT transactionid),
       100.0*SUM(damt)/NULLIF((SELECT d_amt FROM tot),0)
FROM cfbl_d WHERE bf=1
UNION ALL
SELECT 'TIER','MERCHANT_BLACKLIST','EVER_LISTED', NULL, SUM(damt), NULL, COUNT(DISTINCT transactionid),
       100.0*SUM(damt)/NULLIF((SELECT d_amt FROM tot),0)
FROM mr_d
UNION ALL
SELECT 'TIER','MERCHANT_BLACKLIST','LISTED_BEFORE_TXN', NULL, SUM(damt), NULL, COUNT(DISTINCT transactionid),
       100.0*SUM(damt)/NULLIF((SELECT d_amt FROM tot),0)
FROM mr_d WHERE bf=1
UNION ALL
SELECT 'TXN','CF_BLACKLIST', CAST(transactionid AS VARCHAR) || '§' || COALESCE(CAST(list_dt AS VARCHAR),''),
       CAST(txn_amt AS DOUBLE PRECISION), damt, CAST(NULL AS BIGINT), CAST(NULL AS BIGINT), CAST(NULL AS DOUBLE PRECISION)
FROM cfbl_d WHERE bf=1
UNION ALL
SELECT 'TXN','MERCHANT_BLACKLIST', CAST(transactionid AS VARCHAR) || '§' || COALESCE(CAST(list_dt AS VARCHAR),''),
       CAST(txn_amt AS DOUBLE PRECISION), damt, CAST(NULL AS BIGINT), CAST(NULL AS BIGINT), CAST(NULL AS DOUBLE PRECISION)
FROM mr_d WHERE bf=1
ORDER BY metric, dim_value;
