-- Q4 DOT/MNRL tier [MID __MID__]
WITH tx AS (
    SELECT t.transactionid, CAST(t.cforderid AS VARCHAR) AS cforderid, CAST(t.txtime AS DATE) AS txdate, t.amount AS txn_amt
    FROM cfsellers.cftransactions t
    WHERE t.merchantid = __MID__ AND t.txtime >= date_add('day', -__DAYS__, current_date)),
disp_on_txn AS (
    SELECT CAST(md.cftxnid AS VARCHAR) AS cftxnid, MAX(md.disputeamount) AS damt
    FROM cfsellers.merchantdisputes md
    WHERE md.merchantid = __MID__ AND md.addedon >= date_add('day', -__DAYS__, current_date) GROUP BY 1),
dtx AS (SELECT t.transactionid, t.cforderid, t.txdate, t.txn_amt, d.damt FROM tx t JOIN disp_on_txn d ON t.transactionid = d.cftxnid),
ord_ids AS (
    SELECT d.transactionid, d.txdate, d.damt, d.txn_amt,
       CASE WHEN LENGTH(TRIM(o.customerphone)) = 12 AND TRIM(o.customerphone) LIKE '91%'  THEN SUBSTRING(TRIM(o.customerphone), 3)
            WHEN LENGTH(TRIM(o.customerphone)) = 13 AND TRIM(o.customerphone) LIKE '+91%' THEN SUBSTRING(TRIM(o.customerphone), 4)
            WHEN LENGTH(TRIM(o.customerphone)) = 11 AND TRIM(o.customerphone) LIKE '0%'   THEN SUBSTRING(TRIM(o.customerphone), 2)
            ELSE NULLIF(TRIM(o.customerphone), '') END AS phone
    FROM dtx d JOIN cfsellers.cforders o ON d.cforderid = CAST(o.id AS VARCHAR)
    WHERE o.merchantid = __MID__ AND o.addedon >= date_add('day', -__SLACK__, current_date)),
idents AS (SELECT transactionid, txdate, damt, txn_amt, phone AS idvalue FROM ord_ids WHERE phone IS NOT NULL),
ident_phones AS (SELECT DISTINCT idvalue AS phone FROM idents),
matched_dot AS (
    SELECT dm.mobile, CAST(dm.dateofdisconnection AS DATE) AS dt, dm.disconnectionreason
    FROM shield.dotmobiledata dm
    WHERE dm.isactive = 1 AND dm.mobile IN (SELECT phone FROM ident_phones)),
dot_hits AS (
    SELECT DISTINCT i.transactionid, i.damt, i.txn_amt, i.idvalue,
           MAX(CASE WHEN md.dt <= i.txdate THEN 1 ELSE 0 END) AS before_f,
           MIN(CASE WHEN md.dt <= i.txdate THEN md.dt END) AS list_dt
    FROM idents i JOIN matched_dot md ON md.mobile = i.idvalue
    GROUP BY i.transactionid, i.damt, i.txn_amt, i.idvalue),
tot AS (SELECT COUNT(*) AS d_txns, SUM(damt) AS d_amt FROM dtx),
dedup AS (SELECT transactionid, MAX(damt) AS dd, MAX(txn_amt) AS txn_amt, MAX(before_f) AS bf, MIN(list_dt) AS list_dt FROM dot_hits GROUP BY transactionid)
SELECT 'TIER' AS section, 'DOT_MNRL' AS metric, 'EVER_LISTED' AS dim_value,
       CAST(NULL AS DOUBLE PRECISION) AS captured_amt, SUM(dd) AS disputed_amt,
       CAST(NULL AS BIGINT) AS tx_count, COUNT(DISTINCT transactionid) AS dispute_count,
       100.0*SUM(dd)/NULLIF((SELECT d_amt FROM tot),0) AS ratio_pct
FROM dedup
UNION ALL
SELECT 'TIER','DOT_MNRL','LISTED_BEFORE_TXN', NULL, SUM(dd), NULL, COUNT(DISTINCT transactionid),
       100.0*SUM(dd)/NULLIF((SELECT d_amt FROM tot),0)
FROM dedup WHERE bf = 1
UNION ALL
SELECT 'TXN', 'DOT_MNRL', CAST(transactionid AS VARCHAR) || '§' || COALESCE(CAST(list_dt AS VARCHAR),''),
       CAST(txn_amt AS DOUBLE PRECISION), dd, CAST(NULL AS BIGINT), CAST(NULL AS BIGINT), CAST(NULL AS DOUBLE PRECISION)
FROM dedup WHERE bf = 1;
